package com.utsman.binarapp1.data

import java.io.Serializable

data class User(
    val name: String,
    val age: Int
) : Serializable