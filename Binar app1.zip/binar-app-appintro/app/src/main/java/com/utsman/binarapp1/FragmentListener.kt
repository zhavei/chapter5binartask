package com.utsman.binarapp1

interface FragmentListener {
    fun getTextValue(): String
}